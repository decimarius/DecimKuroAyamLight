﻿CREATE TABLE [dbo].[RoomBooking]
(
	[BookingID] INT NOT NULL PRIMARY KEY IDENTITY ,
	[NumberOfAdults] INT NOT NULL,
	[NumberOfChild] INT NOT NULL,
	[BookingDate] DateTime NOT NULL,
	[DepartureDate] DateTime NOT NULL,
	[PaymentMethod] NVARCHAR (50) NOT NULL,
	[Remarks] NVARCHAR (256) NULL,
	[LateCheckout] DateTime NULL, 
	[RoomID] int NOT NULL,
	[CustomerID] int NOT NULL,
    CONSTRAINT [FK_RoomBooking_Room] FOREIGN KEY (RoomID) REFERENCES Room(RoomID), 
    CONSTRAINT [FK_RoomBooking_Customer] FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
)
