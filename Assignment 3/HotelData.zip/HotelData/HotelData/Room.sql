﻿CREATE TABLE [dbo].[Room]
(
	[RoomID] INT NOT NULL PRIMARY KEY IDENTITY,
	[RoomNumber] INT NOT NULL,
	[RoomType] NVARCHAR (50) NOT NULL,
	[RoomFloor] INT NOT NULL,
	[RoomStatus] NVARCHAR (50) NOT NULL
)
