﻿CREATE TABLE [dbo].[Customer]
(
	[CustomerID] INT NOT NULL PRIMARY KEY IDENTITY,
	[FirstName] NVARCHAR (50) NOT NULL,
	[LastName] NVARCHAR (50) NOT NULL,
	[Identification] NVARCHAR (15) NOT NULL,
	[Country] NVARCHAR (30) NOT NULL,
	[Email] NVARCHAR (100) NOT NULL,
	[PhoneNumber] INT NOT NULL,
	[Address] NVARCHAR (256) NOT NULL,
)
