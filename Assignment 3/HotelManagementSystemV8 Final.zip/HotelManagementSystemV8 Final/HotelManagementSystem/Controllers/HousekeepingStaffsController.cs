﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HotelManagementSystem.Models;
using HotelManagementSystem.CustomFilters;

namespace HousekeepingManagementSite.Controllers
{
    public class HousekeepingStaffsController : Controller
    {
        private HotelDataEntities db = new HotelDataEntities();

        // GET: HousekeepingStaffs
        [AuthLog(Roles = "Admin")]
        public ActionResult Index(string SortOrder)
        {

            var emp = from s in db.HousekeepingStaffs select s;

            ViewBag.StaffFirstName = String.IsNullOrEmpty(SortOrder) ? "StaffFirstName_desc" : "";
            ViewBag.StaffLastName = SortOrder == "StaffLastName" ? "StaffLastName_desc" : "StaffLastName";
            ViewBag.DutyTypes = SortOrder == "DutyTypes" ? "DutyTypes_desc" : "DutyTypes";



            switch (SortOrder)
            {
                case "StaffFirstName_desc":
                    emp = emp.OrderByDescending(s => s.StaffFirstName);
                    break;
                case "StaffLastName":
                    emp = emp.OrderBy(s => s.StaffLastName);
                    break;
                case "StaffLastName_desc":
                    emp = emp.OrderByDescending(s => s.StaffLastName);
                    break;
                case "DutyTypes":
                    emp = emp.OrderBy(s => s.DutyTypes);
                    break;
                case "DutyTypes_desc":
                    emp = emp.OrderByDescending(s => s.DutyTypes);
                    break;
                default:
                    emp = emp.OrderBy(s => s.StaffFirstName);
                    break;

            }
            return View(db.HousekeepingStaffs.ToList());
        }

        // GET: HousekeepingStaffs/Details/5
        [AuthLog(Roles = "Admin")]
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HousekeepingStaff housekeepingStaff = db.HousekeepingStaffs.Find(id);
            if (housekeepingStaff == null)
            {
                return HttpNotFound();
            }
            return View(housekeepingStaff);
        }

        // GET: HousekeepingStaffs/Create
        [AuthLog(Roles = "Admin")]
        public ActionResult Create()
        {
            return View();
        }

        // POST: HousekeepingStaffs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [AuthLog(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "StaffUserID,StaffFirstName,StaffLastName,Gender,DateOfBirth,BankAccountNumber,PhoneNumber,DutyTypes")] HousekeepingStaff housekeepingStaff)
        {
            if (ModelState.IsValid)
            {
                db.HousekeepingStaffs.Add(housekeepingStaff);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(housekeepingStaff);
        }


        // GET: HousekeepingStaffs/Edit/5
        [AuthLog(Roles = "Admin")]
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HousekeepingStaff housekeepingStaff = db.HousekeepingStaffs.Find(id);
            if (housekeepingStaff == null)
            {
                return HttpNotFound();
            }
            return View(housekeepingStaff);
        }

        // POST: HousekeepingStaffs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [AuthLog(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "StaffUserID,StaffFirstName,StaffLastName,Gender,DateOfBirth,BankAccountNumber,PhoneNumber,DutyTypes")] HousekeepingStaff housekeepingStaff)
        {
            if (ModelState.IsValid)
            {
                db.Entry(housekeepingStaff).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(housekeepingStaff);
        }

        // GET: HousekeepingStaffs/Delete/5
        [AuthLog(Roles = "Admin")]
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HousekeepingStaff housekeepingStaff = db.HousekeepingStaffs.Find(id);
            if (housekeepingStaff == null)
            {
                return HttpNotFound();
            }
            return View(housekeepingStaff);
        }

        // POST: HousekeepingStaffs/Delete/5
        [AuthLog(Roles = "Admin")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            HousekeepingStaff housekeepingStaff = db.HousekeepingStaffs.Find(id);
            db.HousekeepingStaffs.Remove(housekeepingStaff);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
