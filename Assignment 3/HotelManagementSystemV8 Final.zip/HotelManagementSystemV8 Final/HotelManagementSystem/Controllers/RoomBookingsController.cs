﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HotelManagementSystem.Models;
using System.Diagnostics;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using HotelManagementSystem.CustomFilters;

namespace HotelManagementSystem.Controllers
{
    public class RoomBookingsController : Controller
    {
        private HotelDataEntities db = new HotelDataEntities();

        // GET: RoomBookings
        [AuthLog(Roles = "Admin, Receptionist")]
        public ActionResult Index(string searchString)
        {
            var roomBookings = db.RoomBookings.Include(r => r.Customer).Include(r => r.Room);
            if (!String.IsNullOrEmpty(searchString))
            {
                roomBookings = roomBookings.Where(a => a.Customer.Identification.Contains(searchString));
            }
            return View(roomBookings.ToList());
        }

        [AuthLog(Roles = "Admin, Receptionist")]
        public ActionResult Availability()
        {
            var a = db.Rooms.Where(r => r.RoomStatus == "Available").ToList();
            return View(a);
        }

        // GET: RoomBookings/Details/5
        [AuthLog(Roles = "Admin, Receptionist")]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomBooking roomBooking = db.RoomBookings.Find(id);
            if (roomBooking == null)
            {
                return HttpNotFound();
            }
            return View(roomBooking);
        }

        // GET: RoomBookings/Create
        [AuthLog(Roles = "Admin, Receptionist")]
        public ActionResult Create()
        {
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "Identification");
            var roomTypes = db.Rooms.Select(o => o.RoomType).Distinct().ToList();

            List<SelectListItem> categories = new List<SelectListItem>();
            
            for (int i = 0; i < roomTypes.Count(); i++)
            {
                categories.Add(new SelectListItem() { Text = roomTypes[i], Value = roomTypes[i] });
            }
            
            ViewBag.RoomID = new SelectList(categories, "Value", "Text");
            ViewBag.Rooms = db.Rooms;
            return View();
        }

        // POST: RoomBookings/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthLog(Roles = "Admin, Receptionist")]
        public ActionResult Create([Bind(Include = "BookingID,NumberOfAdults,NumberOfChild,BookingDate,DepartureDate,PaymentMethod,Remarks,LateCheckout,RoomNumber,CustomerID")] RoomBooking roomBooking)
        {
            if (ModelState.IsValid)
            {
                var roomNumber = Int32.Parse(Request.Form.Get("RoomNumber").ToString());
                roomBooking.RoomID = db.Rooms.Where(o => o.RoomNumber == roomNumber).First().RoomID;
                db.RoomBookings.Add(roomBooking);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "Identification", roomBooking.CustomerID);
            var roomTypes = db.Rooms.Select(o => o.RoomType).Distinct().ToList();

            List<SelectListItem> categories = new List<SelectListItem>();

            for (int i = 0; i < roomTypes.Count(); i++)
            {
                categories.Add(new SelectListItem() { Text = roomTypes[i], Value = roomTypes[i] });
            }

            ViewBag.RoomID = new SelectList(categories, "Value", "Text");
            ViewBag.Rooms = db.Rooms;

            return View(roomBooking);
        }

        // GET: RoomBookings/Edit/5
        [AuthLog(Roles = "Admin, Receptionist")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomBooking roomBooking = db.RoomBookings.Find(id);
            if (roomBooking == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "Identification", roomBooking.CustomerID);

            var roomTypes = db.Rooms.Select(o => o.RoomType).Distinct().ToList();

            List<SelectListItem> categories = new List<SelectListItem>();

            for (int i = 0; i < roomTypes.Count(); i++)
            {
                categories.Add(new SelectListItem() { Text = roomTypes[i], Value = roomTypes[i] });
            }
            
            ViewBag.RoomID = new SelectList(categories, "Value", "Text", roomBooking.Room.RoomType);
            ViewBag.Rooms = db.Rooms;

            return View(roomBooking);
        }

        // POST: RoomBookings/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthLog(Roles = "Admin, Receptionist")]
        public ActionResult Edit([Bind(Include = "BookingID,NumberOfAdults,NumberOfChild,BookingDate,DepartureDate,PaymentMethod,Remarks,LateCheckout,RoomNumber,CustomerID")] RoomBooking roomBooking)
        {
            if (ModelState.IsValid)
            {
                var roomNumber = Int32.Parse(Request.Form.Get("RoomNumber").ToString());
                roomBooking.RoomID = db.Rooms.Where(o => o.RoomNumber == roomNumber).First().RoomID;
                db.Entry(roomBooking).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "FirstName", roomBooking.CustomerID);
            ViewBag.RoomID = new SelectList(db.Rooms, "RoomID", "RoomType", roomBooking.RoomID);
            return View(roomBooking);
        }

        // GET: RoomBookings/Delete/5
        [AuthLog(Roles = "Admin, Receptionist")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomBooking roomBooking = db.RoomBookings.Find(id);
            if (roomBooking == null)
            {
                return HttpNotFound();
            }
            return View(roomBooking);
        }

        // POST: RoomBookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [AuthLog(Roles = "Admin, Receptionist")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            RoomBooking roomBooking = db.RoomBookings.Find(id);
            db.RoomBookings.Remove(roomBooking);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }


        // Change room type. Given room type change room number
        public JsonResult ChangeRoomType(string roomType, string bookingDate, string departureDate)
        {
            // 1. Select all the room numbers based on the room type given
            // 2. Filter it down with the following constraints
            // - Today < Booking Start Date (for advanced booking)
            DateTime selectedDate = DateTime.Today;
            if (bookingDate != "")
            {
                try
                {
                    selectedDate = DateTime.ParseExact(bookingDate, "dd/MM/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                }
                catch (FormatException e)
                {
                    // read date from database
                    selectedDate = DateTime.Parse(bookingDate);
                }
            }

            // Default to 1 Day
            DateTime making_depatureDate = selectedDate.AddDays(1);
            if (departureDate != "")
            {
                try
                {
                    making_depatureDate = DateTime.ParseExact(departureDate, "dd/MM/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                }
                catch (FormatException e)
                {
                    // read date from database
                    making_depatureDate = DateTime.Parse(departureDate);
                }
            }

            List<RoomBooking> booking = new List<RoomBooking>();
            List<RoomBooking> all_room_bookings = db.RoomBookings.ToList();

            for (int k = 0; k < db.RoomBookings.Count(); k++)
            {
                RoomBooking b = all_room_bookings[k];
                long booking_departurespan = b.DepartureDate.Ticks;



                long booking_arrivalspan = b.BookingDate.Ticks;
                long making_arrivalspan = selectedDate.Ticks;

                long making_departurespan = making_depatureDate.Ticks;
                
                if ((
                (booking_arrivalspan <= making_arrivalspan) && (making_arrivalspan <= booking_departurespan)
                )
                ||
                (
                (booking_arrivalspan <= making_departurespan) && (making_departurespan <= booking_departurespan)
                ))
                {
                    // add to be removed
                    booking.Add(b);
                }
            }

            List<int> room_ids = new List<int>();

            // adding room id of the booking list
            booking.ForEach(o => room_ids.Add(o.RoomID));

            List<Room> books = new List<Room>();

            for (int i = 0; i < room_ids.Count; i++)
            {
                int r_id = room_ids[i];
                books.Add(db.Rooms.Where(o => o.RoomID == r_id).First());
            }

            List<Room> rooms = (from x in db.Rooms
                                where x.RoomType == roomType
                                select x).ToList();

            List<Room> removed = rooms.Except(books).ToList();



            // filtered list of rooms that are not booked + roomstatus is free
            List<int> val = (from x in removed
                             where (x.RoomType == roomType) && x.RoomStatus == "Available"
                             select x.RoomNumber).ToList();




            return Json(val, JsonRequestBehavior.AllowGet);
        }


    }
}
