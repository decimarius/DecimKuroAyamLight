﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HotelManagementSystem.Models;
using System.Diagnostics;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace HotelManagementSystem.Controllers
{
    public class RoomBookingsController : Controller
    {
        private HotelDataEntities db = new HotelDataEntities();

        // GET: RoomBookings
        public ActionResult Index()
        {
            var roomBookings = db.RoomBookings.Include(r => r.Customer).Include(r => r.Room);
            return View(roomBookings.ToList());
        }

        public ActionResult Availability()
        {
            var a = db.Rooms.Where(r => r.RoomStatus == "Available").ToList();
            return View(a);
        }

        // GET: RoomBookings/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomBooking roomBooking = db.RoomBookings.Find(id);
            if (roomBooking == null)
            {
                return HttpNotFound();
            }
            return View(roomBooking);
        }

        // GET: RoomBookings/Create
        public ActionResult Create()
        {
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "Identification");
            var roomTypes = db.Rooms.Select(o => o.RoomType).Distinct().ToList();

            List<SelectListItem> categories = new List<SelectListItem>();
            
            for (int i = 0; i < roomTypes.Count(); i++)
            {
                categories.Add(new SelectListItem() { Text = roomTypes[i], Value = roomTypes[i] });
            }
            
            ViewBag.RoomID = new SelectList(categories, "Value", "Text");
            ViewBag.Rooms = db.Rooms;
            return View();
        }

        // POST: RoomBookings/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BookingID,NumberOfAdults,NumberOfChild,BookingDate,DepartureDate,PaymentMethod,Remarks,LateCheckout,RoomNumber,CustomerID")] RoomBooking roomBooking)
        {
            if (ModelState.IsValid)
            {
                var roomNumber = Int32.Parse(Request.Form.Get("RoomNumber").ToString());
                roomBooking.RoomID = db.Rooms.Where(o => o.RoomNumber == roomNumber).First().RoomID;
                db.RoomBookings.Add(roomBooking);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "Identification", roomBooking.CustomerID);
            var roomTypes = db.Rooms.Select(o => o.RoomType).Distinct().ToList();

            List<SelectListItem> categories = new List<SelectListItem>();

            for (int i = 0; i < roomTypes.Count(); i++)
            {
                categories.Add(new SelectListItem() { Text = roomTypes[i], Value = roomTypes[i] });
            }

            ViewBag.RoomID = new SelectList(categories, "Value", "Text");
            ViewBag.Rooms = db.Rooms;

            return View(roomBooking);
        }

        // GET: RoomBookings/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomBooking roomBooking = db.RoomBookings.Find(id);
            if (roomBooking == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "Identification", roomBooking.CustomerID);

            var roomTypes = db.Rooms.Select(o => o.RoomType).Distinct().ToList();

            List<SelectListItem> categories = new List<SelectListItem>();

            for (int i = 0; i < roomTypes.Count(); i++)
            {
                categories.Add(new SelectListItem() { Text = roomTypes[i], Value = roomTypes[i] });
            }
            
            ViewBag.RoomID = new SelectList(categories, "Value", "Text", roomBooking.Room.RoomType);
            ViewBag.Rooms = db.Rooms;

            return View(roomBooking);
        }

        // POST: RoomBookings/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BookingID,NumberOfAdults,NumberOfChild,BookingDate,DepartureDate,PaymentMethod,Remarks,LateCheckout,RoomID,CustomerID")] RoomBooking roomBooking)
        {
            if (ModelState.IsValid)
            {
                db.Entry(roomBooking).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CustomerID = new SelectList(db.Customers, "CustomerID", "FirstName", roomBooking.CustomerID);
            ViewBag.RoomID = new SelectList(db.Rooms, "RoomID", "RoomType", roomBooking.RoomID);
            return View(roomBooking);
        }

        // GET: RoomBookings/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomBooking roomBooking = db.RoomBookings.Find(id);
            if (roomBooking == null)
            {
                return HttpNotFound();
            }
            return View(roomBooking);
        }

        // POST: RoomBookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            RoomBooking roomBooking = db.RoomBookings.Find(id);
            db.RoomBookings.Remove(roomBooking);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }


        // Change room type. Given room type change room number
        public JsonResult ChangeRoomType(string roomType, string bookingDate)
        {
            // 1. Select all the room numbers based on the room type given
            // 2. Filter it down with the following constraints
            // - Today < Booking Start Date (for advanced booking)
            DateTime selectedDate = DateTime.Today;
            if (bookingDate != "")
            {
                try
                {
                    selectedDate = DateTime.ParseExact(bookingDate, "MM/dd/yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                }
                catch (FormatException e)
                {
                    // read date from database
                    selectedDate = DateTime.Parse(bookingDate);
                }
            }
            // Assumptions 

            List<RoomBooking> booking = db.RoomBookings.Where(o => (selectedDate > o.DepartureDate)).ToList();


            for (int i = 0; i < booking.Count(); i++)
            {
                long durationspan = ((booking[i].LateCheckout.HasValue) ?
                    booking[i].LateCheckout.Value.Ticks :
                    booking[i].DepartureDate.Ticks);

                if (selectedDate.Ticks > durationspan)
                {
                    booking.RemoveAt(i);
                }
            }

            List<int> room_ids = new List<int>();
            booking.ForEach(o => room_ids.Add(o.RoomID));

            List<Room> books = new List<Room>();

            for (int i = 0; i < room_ids.Count; i++)
            {
                int r_id = room_ids[i];
                books.Add(db.Rooms.Where(o => o.RoomID == r_id).First());
            }

            List<Room> rooms = (from x in db.Rooms
                                where x.RoomType == roomType
                                select x).ToList();

            List<Room> removed = rooms.Except(books).ToList();



            // filtered list of rooms that are not booked + roomstatus is free
            List<int> val = (from x in removed
                             where (x.RoomType == roomType) && x.RoomStatus == "Available"
                             select x.RoomNumber).ToList();




            return Json(val, JsonRequestBehavior.AllowGet);
        }


    }
}
