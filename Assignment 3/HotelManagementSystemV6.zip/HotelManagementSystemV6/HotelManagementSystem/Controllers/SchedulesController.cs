﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HotelManagementSystem.Models;

namespace HousekeepingManagementSite.Controllers
{
    public class SchedulesController : Controller
    {
        private HotelDataEntities db = new HotelDataEntities();


        public ActionResult Index(string SortOrder, string SearchString)
        {
            var schedules = db.Schedules.Include(s => s.Day).Include(s => s.HousekeepingStaff).Where(s => s.Room.RoomStatus != "Maintenance" && s.Room.RoomStatus != "Occupied").Include(s => s.Time);

            if (!String.IsNullOrEmpty(SearchString))
            {
                schedules = schedules.Where(a => a.StaffUserID.Contains(SearchString));

            }

            ViewBag.DutyDay = String.IsNullOrEmpty(SortOrder) ? "DutyDay_desc" : "";
            ViewBag.DutyTime = SortOrder == "DutyTime" ? "DutyTime_desc" : "DutyTime";
            ViewBag.StaffUserID = SortOrder == "StaffUserID" ? "StaffUserID_desc" : "StaffUserID";


            switch (SortOrder)
            {
                case "DutyDay_desc":
                    schedules = schedules.OrderByDescending(s => s.DutyDay);
                    break;
                case "DutyTime":
                    schedules = schedules.OrderBy(s => s.DutyTime);
                    break;
                case "DutyTime_desc":
                    schedules = schedules.OrderByDescending(s => s.DutyTime);
                    break;
                case "StaffUserID":
                    schedules = schedules.OrderBy(s => s.StaffUserID);
                    break;
                case "StaffUserID_desc":
                    schedules = schedules.OrderByDescending(s => s.StaffUserID);
                    break;
                default:
                    schedules = schedules.OrderBy(s => s.DutyDay);
                    break;

            }

            return View(schedules.ToList());
        }

        // GET: Schedules
        public ActionResult StaffView(string SortOrder, string SearchString)
        {
            var schedules = db.Schedules.Include(s => s.Day).Include(s => s.HousekeepingStaff).Where(s => s.Room.RoomStatus != "Maintenance" && s.Room.RoomStatus != "Occupied").Include(s => s.Time);

            if (!String.IsNullOrEmpty(SearchString))
            {
                schedules = schedules.Where(a => a.StaffUserID.Contains(SearchString));

            }

            ViewBag.DutyDay = String.IsNullOrEmpty(SortOrder) ? "DutyDay_desc" : "";
            ViewBag.DutyTime = SortOrder == "DutyTime" ? "DutyTime_desc" : "DutyTime";
            ViewBag.StaffUserID = SortOrder == "StaffUserID" ? "StaffUserID_desc" : "StaffUserID";


            switch (SortOrder)
            {
                case "DutyDay_desc":
                    schedules = schedules.OrderByDescending(s => s.DutyDay);
                    break;
                case "DutyTime":
                    schedules = schedules.OrderBy(s => s.DutyTime);
                    break;
                case "DutyTime_desc":
                    schedules = schedules.OrderByDescending(s => s.DutyTime);
                    break;
                case "StaffUserID":
                    schedules = schedules.OrderBy(s => s.StaffUserID);
                    break;
                case "StaffUserID_desc":
                    schedules = schedules.OrderByDescending(s => s.StaffUserID);
                    break;
                default:
                    schedules = schedules.OrderBy(s => s.DutyDay);
                    break;

            }

            return View(schedules.ToList());
        }

        // GET: Schedules
        public ActionResult CustomerView(string SortOrder)
        {
            var schedules = db.Schedules.Include(s => s.Day).Include(s => s.HousekeepingStaff).Where(s => s.Room.RoomStatus != "Maintenance").Include(s => s.Time);

            ViewBag.DutyDay = String.IsNullOrEmpty(SortOrder) ? "DutyDay_desc" : "";
            ViewBag.DutyTime = SortOrder == "DutyTime" ? "DutyTime_desc" : "DutyTime";
            ViewBag.StaffUserID = SortOrder == "StaffUserID" ? "StaffUserID_desc" : "StaffUserID";


            switch (SortOrder)
            {
                case "DutyDay_desc":
                    schedules = schedules.OrderByDescending(s => s.DutyDay);
                    break;
                case "DutyTime":
                    schedules = schedules.OrderBy(s => s.DutyTime);
                    break;
                case "DutyTime_desc":
                    schedules = schedules.OrderByDescending(s => s.DutyTime);
                    break;
                case "StaffUserID":
                    schedules = schedules.OrderBy(s => s.StaffUserID);
                    break;
                case "StaffUserID_desc":
                    schedules = schedules.OrderByDescending(s => s.StaffUserID);
                    break;
                default:
                    schedules = schedules.OrderBy(s => s.DutyDay);
                    break;

            }

            return View(schedules.ToList());
        }


        // GET: Schedules/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Schedule schedule = db.Schedules.Find(id);
            if (schedule == null)
            {
                return HttpNotFound();
            }
            return View(schedule);
        }

        // GET: Schedules/Create
        public ActionResult Create()
        {
            ViewBag.DutyDay = new SelectList(db.Days, "DutyDay", "DutyDay");
            ViewBag.StaffUserID = new SelectList(db.HousekeepingStaffs, "StaffUserID", "StaffUserID");
            ViewBag.RoomID = new SelectList(db.Rooms, "RoomID", "RoomNumber");
            ViewBag.DutyTime = new SelectList(db.Times, "DutyTime", "DutyTime");
            return View();
        }

        // POST: Schedules/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ScheduleID,StaffUserID,DutyDay,DutyTime,Remarks,RoomID")] Schedule schedule)
        {
            if (ModelState.IsValid)
            {
                db.Schedules.Add(schedule);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DutyDay = new SelectList(db.Days, "DutyDay", "DutyDay", schedule.DutyDay);
            ViewBag.StaffUserID = new SelectList(db.HousekeepingStaffs, "StaffUserID", "StaffUserID", schedule.StaffUserID);
            ViewBag.RoomID = new SelectList(db.Rooms, "RoomID", "RoomNumber", schedule.RoomID);
            ViewBag.DutyTime = new SelectList(db.Times, "DutyTime", "DutyTime", schedule.DutyTime);
            return View(schedule);
        }

        // GET: Schedules/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Schedule schedule = db.Schedules.Find(id);
            if (schedule == null)
            {
                return HttpNotFound();
            }
            ViewBag.DutyDay = new SelectList(db.Days, "DutyDay", "DutyDay", schedule.DutyDay);
            ViewBag.StaffUserID = new SelectList(db.HousekeepingStaffs, "StaffUserID", "StaffFirstName", schedule.StaffUserID);
            ViewBag.RoomID = new SelectList(db.Rooms, "RoomID", "RoomNumber", schedule.RoomID);
            ViewBag.DutyTime = new SelectList(db.Times, "DutyTime", "DutyTime", schedule.DutyTime);
            return View(schedule);
        }

        // POST: Schedules/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ScheduleID,StaffUserID,DutyDay,DutyTime,Remarks,RoomID")] Schedule schedule)
        {
            if (ModelState.IsValid)
            {
                db.Entry(schedule).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DutyDay = new SelectList(db.Days, "DutyDay", "DutyDay", schedule.DutyDay);
            ViewBag.StaffUserID = new SelectList(db.HousekeepingStaffs, "StaffUserID", "StaffFirstName", schedule.StaffUserID);
            ViewBag.RoomID = new SelectList(db.Rooms, "RoomID", "RoomNumber", schedule.RoomID);
            ViewBag.DutyTime = new SelectList(db.Times, "DutyTime", "DutyTime", schedule.DutyTime);
            return View(schedule);
        }

        // GET: Schedules/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Schedule schedule = db.Schedules.Find(id);
            if (schedule == null)
            {
                return HttpNotFound();
            }
            return View(schedule);
        }

        // POST: Schedules/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Schedule schedule = db.Schedules.Find(id);
            db.Schedules.Remove(schedule);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
